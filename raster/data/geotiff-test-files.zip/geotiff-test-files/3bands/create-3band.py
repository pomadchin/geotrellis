import os, shutil
from subprocess import call

types = ['byte',
     'uint16',
     'int16',
     'uint32',
     'int32',
     'float32',
     'float64']

files = [('3bands-striped-pixel.tif', ""),
         ('3bands-tiled-pixel.tif', "-co tiled=yes -co blockxsize=16 -co blockysize=16"),
         ('3bands-striped-band.tif', "-co interleave=band"),
         ('3bands-tiled-band.tif', "-co interleave=band -co tiled=yes -co blockxsize=16 -co blockysize=16")]

storage = ['striped', 'tiled']
interleave = ['pixel', 'band']

for t in types:
    if not os.path.exists(t):
        print t
        os.mkdir(t)

    for (f, options) in files:
        cmd = "gdal_translate -ot %s %s %s %s/%s" % (t, options, f, t, f)
        call(cmd, shell=True)
